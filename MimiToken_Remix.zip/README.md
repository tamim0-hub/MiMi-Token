# Mimi Token (MIMI)

A simple ERC20-compatible token built for the Polygon blockchain, deployable using Remix IDE.

## Token Information
- **Name:** Mimi Token
- **Symbol:** MIMI
- **Decimals:** 18
- **Total Supply:** 1,000,000 MIMI
- **Network:** Polygon Mainnet or Mumbai Testnet

## Deployment Steps (via Remix)
1. Open [Remix IDE](https://remix.ethereum.org)
2. Create a file named `MimiToken.sol` inside a `contracts` folder.
3. Paste the Solidity code from this repository.
4. Compile using Solidity ^0.8.0 (enable optimization if desired).
5. Deploy using Injected Web3 (MetaMask connected to Polygon or Mumbai).
6. Confirm transaction on MetaMask and verify the contract on PolygonScan.

## License
MIT License © 2025 Abir Jan
